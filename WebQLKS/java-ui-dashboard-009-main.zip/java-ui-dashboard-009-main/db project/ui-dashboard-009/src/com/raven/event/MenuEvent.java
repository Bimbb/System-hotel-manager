package com.raven.event;

public interface MenuEvent {

    public void menuSelected(int index);
}
